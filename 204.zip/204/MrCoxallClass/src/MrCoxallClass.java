/*******************************************************************************
*
* Created by: Matthew Brean
* Created on: 2019-09-30
* Created for: ICS4U
* Daily Assignment: #2-04
* Stack class
*
*******************************************************************************/

import java.util.ArrayList;


public class MrCoxallClass {

    private ArrayList<String> _theStackList = new ArrayList<String>();
	
    public void push(String valueToPutOnStack) {
		
        _theStackList.add(valueToPutOnStack);
        System.out.println(_theStackList);
    }
    
    public void pop(String valueToPutOnStack) {

        _theStackList.remove(valueToPutOnStack);
        System.out.println(_theStackList);
    }
    
    public void peek(String valueToPutOnStack) {
    	
        System.out.println(_theStackList.get(_theStackList.size()-1));
    }
    
    public void clear(String valueToPutOnStack) {

        _theStackList.clear();
        System.out.println(_theStackList);
    }
    
}